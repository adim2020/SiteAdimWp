=== TZ Feature Pack ===

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Special collection of widgets & shortcodes for J-Shop Theme.

== Changelog ==

= 1.3.1 =
* Elementor Header functionality added

= 1.0.0 =
* Release
